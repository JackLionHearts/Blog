#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <getopt.h>  
#include <fcntl.h>  
#include <unistd.h>
#include <malloc.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <asm/types.h> /* for videodev2.h */
#include <linux/videodev2.h>
#include <opencv2/opencv.hpp>

#include <jpeglib.h>
#include <iostream>
#include <boost/thread/thread.hpp>
#define CLEAR(x) memset (&(x), 0, sizeof (x))

#define Img_WIDTH 1504
#define Img_HEIGHT 1504
#define YUYV    //YUYV  MJEGP
#define ShowImg false //YUYV  MJEGP
#define FrameRate 30

typedef enum {
	IO_METHOD_READ,
	IO_METHOD_MMAP,
	IO_METHOD_USERPTR,
} io_method;

struct buffer {
	void * start;
	size_t length;
};

static char * dev_name = NULL;
static io_method io = IO_METHOD_MMAP;
static int fd = -1;
struct buffer * buffers = NULL;
static unsigned int n_buffers = 0;
static void errno_exit(const char * s)
{
	fprintf(stderr, "%s error %d, %s\n", s, errno, strerror(errno));
	exit(EXIT_FAILURE);
}
static int xioctl(int fd, int request, void * arg)
{
	int r;
	do r = ioctl(fd, request, arg);// ioctl���豸���������ж��豸��I/Oͨ�����й����ĺ�������ν��I/Oͨ�����й��������Ƕ��豸��һЩ���Խ��п��ƣ����紮�ڵĴ��䲨���ʡ������ת�ٵȵȡ����ĵ��ø�������
	while (-1 == r && EINTR == errno);
	return r;
}
static void process_image(const void * p)
{
	fputc('.', stdout);
	fputc('.', stdout);
	fflush(stdout);
}
double t_old;
static void process_image(const void * p, int length)
{
	// std::cout<<"length = "<<length<<std::endl;  
	double t = ((double)cv::getTickCount() - t_old) / cv::getTickFrequency();
	// std::cout<<" t = "<<t*1000<<" ms"<<std::endl;
	t_old = (double)cv::getTickCount();

#ifdef YUYV
	cv::Mat M(Img_HEIGHT, Img_WIDTH, CV_8U);
	uchar *data = (uchar*)M.data;
	for (int i = 0; i < Img_HEIGHT*Img_WIDTH; i++)
	{
		data[i] = *((uchar*)p + 2 * i);
	}
	if (ShowImg)
	{
		cv::imshow("img_gray", M);
		cv::waitKey(1);
	}
#endif
#ifdef MJPEG
	cv::Mat M(Img_HEIGHT, Img_WIDTH * 2, CV_8U);
	uchar *data = (uchar*)M.data;
	for (int i = 0; i < Img_HEIGHT*Img_WIDTH * 2; i++)
	{
		data[i] = *((uchar*)p + i);
	}
	cv::Mat A = cv::imdecode(M, cv::IMREAD_GRAYSCALE);
	cv::imshow("img_gray", A);
	cv::waitKey(1);
	if (ShowImg)
	{
		cv::imshow("img_gray", M);
		cv::waitKey(1);
	}
#endif
}

static int read_frame(void)
{
	struct v4l2_buffer buf;
	unsigned int i;
	switch (io) {
	case IO_METHOD_READ:
		if (-1 == read(fd, buffers[0].start, buffers[0].length)) {
			switch (errno)
			{
			case EAGAIN:
				return 0;
			case EIO:
				/* Could ignore EIO, see spec. */
				/* fall through */
			default:
				errno_exit("read");
			}
		}
		process_image(buffers[0].start, buffers[0].length);
		break;
	case IO_METHOD_MMAP:
		CLEAR(buf);
		buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		buf.memory = V4L2_MEMORY_MMAP;
		if (-1 == xioctl(fd, VIDIOC_DQBUF, &buf)) {
			switch (errno) {
			case EAGAIN:
				return 0;
			case EIO:
				/* Could ignore EIO, see spec. */
				/* fall through */
			default:
				errno_exit("VIDIOC_DQBUF");
			}
		}
		assert(buf.index < n_buffers);
		process_image(buffers[buf.index].start, buffers[buf.index].length);
		{
			FILE *fp = NULL;
			// fp = fopen("/home/huajun/hj/test.jpg", "w");
			if (fp != NULL)
			{
				// fwrite(buffers[buf.index].start, 1, buffers[buf.index].length, fp);
				sync();
				// fclose(fp);
			}
		}

		if (-1 == xioctl(fd, VIDIOC_QBUF, &buf))
			errno_exit("VIDIOC_QBUF");
		break;
	case IO_METHOD_USERPTR:
		CLEAR(buf);
		buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		buf.memory = V4L2_MEMORY_USERPTR;
		if (-1 == xioctl(fd, VIDIOC_DQBUF, &buf)) {
			switch (errno) {
			case EAGAIN:
				return 0;
			case EIO:
				/* Could ignore EIO, see spec. */
				/* fall through */
			default:
				errno_exit("VIDIOC_DQBUF");
			}
		}
		for (i = 0; i < n_buffers; ++i)
			if (buf.m.userptr == (unsigned long)buffers[i].start && buf.length == buffers[i].length)
				break;
		assert(i < n_buffers);
		process_image((void *)buf.m.userptr);
		if (-1 == xioctl(fd, VIDIOC_QBUF, &buf))
			errno_exit("VIDIOC_QBUF");
		break;
	}
	return 1;
}

static void mainloop(void)
{
	unsigned int count;
	count = 100;
	while (1) {
		for (;;) {
			fd_set fds;
			struct timeval tv;
			int r;
			FD_ZERO(&fds); //��ָ�����ļ�����������գ��ڶ��ļ����������Ͻ�������ǰ�����������г�ʼ�����������գ�������ϵͳ�����ڴ�ռ��ͨ����������մ��������Խ���ǲ���֪�ġ�
			FD_SET(fd, &fds); //�������ļ�����������������һ���µ��ļ��������� 

			// std::cout<<" fd = "<<fd<<std::endl;
			/* Timeout. */
			tv.tv_sec = 4;
			tv.tv_usec = 0;
			// t_old = (double)cv::getTickCount();
			r = select(fd + 1, &fds, NULL, NULL, &tv); //�����ڷ������У���һ���׽��ֻ�һ���׽������ź�ʱ֪ͨ�㣬ϵͳ�ṩselect������ʵ�ֶ�·��������/���ģ��
			// double t = ((double)cv::getTickCount()-t_old)/cv::getTickFrequency();
			// std::cout<<" t = "<<t*1000<<" ms"<<std::endl;
			if (-1 == r) {
				if (EINTR == errno)
					continue;
				errno_exit("select");
			}
			if (0 == r) {
				fprintf(stderr, "select timeout\n");
				exit(EXIT_FAILURE);
			}
			if (read_frame())
			{
				break;
			}
			/* EAGAIN - continue select loop. */
		}
	}
}
static void stop_capturing(void)
{
	enum v4l2_buf_type type;
	switch (io) {
	case IO_METHOD_READ:
		/* Nothing to do. */
		break;
	case IO_METHOD_MMAP:
	case IO_METHOD_USERPTR:
		type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		if (-1 == xioctl(fd, VIDIOC_STREAMOFF, &type))
			errno_exit("VIDIOC_STREAMOFF");
		break;
	}
}
static void start_capturing(void)
{
	unsigned int i;
	enum v4l2_buf_type type;
	switch (io) {
	case IO_METHOD_READ:
		/* Nothing to do. */
		break;
	case IO_METHOD_MMAP:
		for (i = 0; i < n_buffers; ++i) {
			struct v4l2_buffer buf;
			CLEAR(buf);
			buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
			buf.memory = V4L2_MEMORY_MMAP;
			buf.index = i;
			if (-1 == xioctl(fd, VIDIOC_QBUF, &buf))
				errno_exit("VIDIOC_QBUF");
		}
		type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		if (-1 == xioctl(fd, VIDIOC_STREAMON, &type))
			errno_exit("VIDIOC_STREAMON");
		break;
	case IO_METHOD_USERPTR:
		for (i = 0; i < n_buffers; ++i) {
			struct v4l2_buffer buf;
			CLEAR(buf);
			buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
			buf.memory = V4L2_MEMORY_USERPTR;
			buf.m.userptr = (unsigned long)buffers[i].start;
			buf.length = buffers[i].length;
			if (-1 == xioctl(fd, VIDIOC_QBUF, &buf))
				errno_exit("VIDIOC_QBUF");
		}
		type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		if (-1 == xioctl(fd, VIDIOC_STREAMON, &type))
			errno_exit("VIDIOC_STREAMON");
		break;
	}
}

static void uninit_device(void)
{
	unsigned int i;
	switch (io) {
	case IO_METHOD_READ:
		free(buffers[0].start);
		break;
	case IO_METHOD_MMAP:
		for (i = 0; i < n_buffers; ++i)
			if (-1 == munmap(buffers[i].start, buffers[i].length))
				errno_exit("munmap");
		break;
	case IO_METHOD_USERPTR:
		for (i = 0; i < n_buffers; ++i)
			free(buffers[i].start);
		break;
	}
	free(buffers);
}

static void init_read(unsigned int buffer_size)
{
	buffers = (buffer*)calloc(1, sizeof(*buffers));//�ڴ�Ķ�̬�洢���з���n������Ϊsize�������ռ䣬��������һ��ָ�������ʼ��ַ��ָ��
	if (!buffers) {
		fprintf(stderr, "Out of memory\n");
		exit(EXIT_FAILURE);
	}
	buffers[0].length = buffer_size;
	buffers[0].start = malloc(buffer_size); //malloc ��ϵͳ�������ָ��size���ֽڵ��ڴ�ռ䡣���������� void* ����
	if (!buffers[0].start) {
		fprintf(stderr, "Out of memory\n");
		exit(EXIT_FAILURE);
	}
}

static void init_mmap(void)
{
	struct v4l2_requestbuffers req;
	CLEAR(req);
	req.count = 4;
	req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	req.memory = V4L2_MEMORY_MMAP;
	if (-1 == xioctl(fd, VIDIOC_REQBUFS, &req)) { //�������ɸ�֡������
		if (EINVAL == errno) {
			fprintf(stderr, "%s does not support "
				"memory mapping\n", dev_name);
			exit(EXIT_FAILURE);
		}
		else {
			errno_exit("VIDIOC_REQBUFS");
		}
	}
	if (req.count < 2) {
		fprintf(stderr, "Insufficient buffer memory on %s\n", dev_name);
		exit(EXIT_FAILURE);
	}
	buffers = (buffer*)calloc(req.count, sizeof(*buffers));
	if (!buffers) {
		fprintf(stderr, "Out of memory\n");
		exit(EXIT_FAILURE);
	}
	for (n_buffers = 0; n_buffers < req.count; ++n_buffers) {
		struct v4l2_buffer buf;
		CLEAR(buf);
		buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		buf.memory = V4L2_MEMORY_MMAP;
		buf.index = n_buffers;
		if (-1 == xioctl(fd, VIDIOC_QUERYBUF, &buf))   //��ѯ֡���������ں��е�ƫ�����ͳ���
			errno_exit("VIDIOC_QUERYBUF");
		buffers[n_buffers].length = buf.length;
		buffers[n_buffers].start = mmap(NULL, buf.length, PROT_READ | PROT_WRITE, MAP_SHARED, fd, buf.m.offset);
		if (MAP_FAILED == buffers[n_buffers].start)
			errno_exit("mmap");
	}
}

static void init_userp(unsigned int buffer_size)
{
	struct v4l2_requestbuffers req;
	CLEAR(req);
	req.count = 4;
	req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	req.memory = V4L2_MEMORY_USERPTR;
	if (-1 == xioctl(fd, VIDIOC_REQBUFS, &req)) {
		if (EINVAL == errno) {
			fprintf(stderr, "%s does not support "
				"user pointer i/o\n", dev_name);
			exit(EXIT_FAILURE);
		}
		else {
			errno_exit("VIDIOC_REQBUFS");
		}
	}
	buffers = (buffer*)calloc(4, sizeof(*buffers));
	if (!buffers) {
		fprintf(stderr, "Out of memory\n");
		exit(EXIT_FAILURE);
	}
	for (n_buffers = 0; n_buffers < 4; ++n_buffers) {
		buffers[n_buffers].length = buffer_size;
		buffers[n_buffers].start = malloc(buffer_size);
		if (!buffers[n_buffers].start) {
			fprintf(stderr, "Out of memory\n");
			exit(EXIT_FAILURE);
		}
	}
}

static void init_device(void)
{
	struct v4l2_capability cap;    //��ѯ�豸����
	struct v4l2_cropcap cropcap;   //��������ͷ�Ĳ�׽����
	struct v4l2_crop crop;
	struct v4l2_format fmt;    //��������ͷ����Ƶ��ʽ��֡��ʽ��
	unsigned int min;
	if (-1 == xioctl(fd, VIDIOC_QUERYCAP, &cap)) { //ʹ��ioctl VIDIOC_QUERYCAP ����ѯ��ǰdriver�Ƿ�Ϻ��淶 ��ΪV4L2Ҫ������driver ��Device��֧�����Ioctl
		if (EINVAL == errno) {  /* Invalid argument */
			fprintf(stderr, "%s is no V4L2 device\n",
				dev_name);
			exit(EXIT_FAILURE);
		}
		else {
			errno_exit("VIDIOC_QUERYCAP");
		}
	}
	if (!(cap.capabilities & V4L2_CAP_VIDEO_CAPTURE)) {
		fprintf(stderr, "%s is no video capture device\n",
			dev_name);
		exit(EXIT_FAILURE);
	}
	switch (io) {
	case IO_METHOD_READ:
		if (!(cap.capabilities & V4L2_CAP_READWRITE)) {
			fprintf(stderr, "%s does not support read i/o\n",
				dev_name);
			exit(EXIT_FAILURE);
		}
		break;
	case IO_METHOD_MMAP:
	case IO_METHOD_USERPTR:
		if (!(cap.capabilities & V4L2_CAP_STREAMING)) {
			fprintf(stderr, "%s does not support streaming i/o\n",
				dev_name);
			exit(EXIT_FAILURE);
		}
		break;
	}
	/* Select video input, video standard and tune here. */
	CLEAR(cropcap);
	cropcap.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	if (0 == xioctl(fd, VIDIOC_CROPCAP, &cropcap)) {  //��ѯ���������� 
		crop.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		crop.c = cropcap.defrect; /* reset to default */  //c�Ǳ�ʾ�ɼ����ڵĴ�С�Ľṹ�壬
		if (-1 == xioctl(fd, VIDIOC_S_CROP, &crop)) {
			switch (errno) {
			case EINVAL:
				/* Cropping not supported. */
				break;
			default:
				/* Errors ignored. */
				break;
			}
		}
	}
	else {
		/* Errors ignored. */
	}

	int ret;
	struct v4l2_fmtdesc fmt_my;
	memset(&fmt_my, 0, sizeof(fmt_my));
	fmt_my.index = 0;
	fmt_my.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	while ((ret = ioctl(fd, VIDIOC_ENUM_FMT, &fmt_my)) == 0) {  //��ѯ֧�ֵĸ�ʽ
		printf("{ pixelformat = '%c%c%c%c', description = '%s' }\n",
			fmt_my.pixelformat & 0xFF, (fmt_my.pixelformat >> 8) & 0xFF,
			(fmt_my.pixelformat >> 16) & 0xFF, (fmt_my.pixelformat >> 24) & 0xFF,
			fmt_my.description);
		fmt_my.index++;
	}

	CLEAR(fmt);
	fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	fmt.fmt.pix.width = Img_WIDTH;
	fmt.fmt.pix.height = Img_HEIGHT;
#ifdef YUYV
	fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV;//V4L2_PIX_FMT_MJPEG;//
#endif
#ifdef MJPEG
	fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_MJPEG;//V4L2_PIX_FMT_YUYV;//
#endif
	fmt.fmt.pix.field = V4L2_FIELD_INTERLACED;
	if (-1 == xioctl(fd, VIDIOC_S_FMT, &fmt))
		errno_exit("VIDIOC_S_FMT");
	/* Note VIDIOC_S_FMT may change width and height. */
	/* Buggy driver paranoia. */
	min = fmt.fmt.pix.width * 2;
	if (fmt.fmt.pix.bytesperline < min)
		fmt.fmt.pix.bytesperline = min;
	min = fmt.fmt.pix.bytesperline * fmt.fmt.pix.height;
	if (fmt.fmt.pix.sizeimage < min)
		fmt.fmt.pix.sizeimage = min;



	struct v4l2_streamparm Stream_Parm;
	memset(&Stream_Parm, 0, sizeof(struct v4l2_streamparm));
	Stream_Parm.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	Stream_Parm.parm.capture.timeperframe.denominator = FrameRate; //��ĸ
	Stream_Parm.parm.capture.timeperframe.numerator = 1;  //����
	if (-1 == xioctl(fd, VIDIOC_S_PARM, &Stream_Parm))  //����֡��
	{
		printf("Set frame rate failed\n");
	}
	memset(&Stream_Parm, 0, sizeof(struct v4l2_streamparm));
	Stream_Parm.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	if (-1 == xioctl(fd, VIDIOC_G_PARM, &Stream_Parm))  //��ȡ֡��
	{
		printf("Get frame rate failed\n");
	}
	int capability = Stream_Parm.parm.capture.capability;
	int capturemode = Stream_Parm.parm.capture.capturemode;
	int numerator = Stream_Parm.parm.capture.timeperframe.numerator;
	int denominator = Stream_Parm.parm.capture.timeperframe.denominator;
	std::cout << " numerator = " << numerator << std::endl;
	std::cout << " denominator = " << denominator << std::endl;
	std::cout << " capability = " << capability << std::endl;  //4096 ��ʾ������֡��
	std::cout << " capturemode = " << capturemode << std::endl;  //

	struct v4l2_queryctrl  Setting;
	Setting.id = V4L2_CID_GAIN;
	if (-1 == xioctl(fd, VIDIOC_QUERYCTRL, &Setting))  //��ѯ֧�ֵ���������
	{
		printf(" Query GAIN settings failed \n");
	}
	else
		printf(" V4L2_CID_GAIN Setting \n minimum = '%d' maximum = '%d' step = '%d' default_value = '%d' \n",
			Setting.minimum, Setting.maximum, Setting.step, Setting.default_value);

	struct v4l2_control ctrl;
	ctrl.id = V4L2_CID_GAIN;
	ctrl.value = 4;
	if (-1 == ioctl(fd, VIDIOC_S_CTRL, &ctrl))  //��������
	{
		printf(" Set GAIN failed \n");
	}

	Setting.id = V4L2_CID_EXPOSURE_ABSOLUTE;
	if (-1 == xioctl(fd, VIDIOC_QUERYCTRL, &Setting))  //��ѯ֧�ֵ��ع�ʱ��
	{
		printf(" Query EXPOSURE settings failed \n");
	}
	else
		printf(" V4L2_CID_EXPOSURE Setting \n minimum = '%d' maximum = '%d' step = '%d' default_value = '%d' \n",
			Setting.minimum, Setting.maximum, Setting.step, Setting.default_value);

	ctrl.id = V4L2_CID_EXPOSURE_AUTO;
	ctrl.value = V4L2_EXPOSURE_MANUAL;
	if (-1 == ioctl(fd, VIDIOC_S_CTRL, &ctrl))  //�����ع�ģʽ
	{
		printf("  set EXPOSURE Mode failed\n");
	}
	ctrl.id = V4L2_CID_EXPOSURE_ABSOLUTE;
	ctrl.value = 300;
	if (-1 == ioctl(fd, VIDIOC_S_CTRL, &ctrl))   //�����ع�ʱ��
	{
		printf("  set EXPOSURE Time failed\n");
	}

	Setting.id = V4L2_CID_BRIGHTNESS;
	if (-1 == xioctl(fd, VIDIOC_QUERYCTRL, &Setting))  //��ѯ֧�ֵ�����
	{
		printf(" Query BRIGHTNESS settings failed \n");
	}
	else
		printf(" V4L2_CID_BRIGHTNESS Setting \n minimum = '%d' maximum = '%d' step = '%d' default_value = '%d' \n",
			Setting.minimum, Setting.maximum, Setting.step, Setting.default_value);
	ctrl.id = V4L2_CID_BRIGHTNESS;
	ctrl.value = 0;
	if (-1 == ioctl(fd, VIDIOC_S_CTRL, &ctrl))   //��������
	{
		printf("set BRIGHTNESS failed\n");
	}


	Setting.id = V4L2_CID_CONTRAST;
	if (-1 == xioctl(fd, VIDIOC_QUERYCTRL, &Setting))  //��ѯ֧�ֵĶԱȶ�
	{
		printf(" Query CONTRAST settings failed \n");
	}
	else
		printf(" V4L2_CID_CONTRAST Setting \n minimum = '%d' maximum = '%d' step = '%d' default_value = '%d' \n",
			Setting.minimum, Setting.maximum, Setting.step, Setting.default_value);
	ctrl.id = V4L2_CID_CONTRAST;
	ctrl.value = 0;
	if (-1 == ioctl(fd, VIDIOC_S_CTRL, &ctrl))   //���öԱȶ�
	{
		printf("set BRIGHTNESS failed\n");
	}


	Setting.id = V4L2_CID_SATURATION;
	if (-1 == xioctl(fd, VIDIOC_QUERYCTRL, &Setting))  //��ѯ֧�ֵı��Ͷ�
	{
		printf(" Query SATURATION settings failed \n");
	}
	else
		printf(" V4L2_CID_SATURATION Setting \n minimum = '%d' maximum = '%d' step = '%d' default_value = '%d' \n",
			Setting.minimum, Setting.maximum, Setting.step, Setting.default_value);
	ctrl.id = V4L2_CID_SATURATION;
	ctrl.value = 0;
	if (-1 == xioctl(fd, VIDIOC_S_CTRL, &ctrl))   //���ñ��Ͷ�
	{
		printf("set BRIGHTNESS failed\n");
	}

	Setting.id = V4L2_CID_HUE;
	if (-1 == xioctl(fd, VIDIOC_QUERYCTRL, &Setting))  //��ѯ֧�ֵ�ɫ��
	{
		printf(" Query HUE settings failed \n");
	}
	else
		printf(" V4L2_CID_HUE Setting \n minimum = '%d' maximum = '%d' step = '%d' default_value = '%d' \n",
			Setting.minimum, Setting.maximum, Setting.step, Setting.default_value);
	ctrl.id = V4L2_CID_HUE;
	ctrl.value = 0;
	if (-1 == xioctl(fd, VIDIOC_S_CTRL, &ctrl))   //����ɫ��
	{
		printf("set HUE failed\n");
	}

	switch (io) {
	case IO_METHOD_READ:
		init_read(fmt.fmt.pix.sizeimage);
		break;
	case IO_METHOD_MMAP:
		init_mmap();
		break;
	case IO_METHOD_USERPTR:
		init_userp(fmt.fmt.pix.sizeimage);
		break;
	}
}

static void close_device(void)
{
	if (-1 == close(fd))
		errno_exit("close");
	fd = -1;
}

static void open_device(void)
{
	struct stat st;
	if (-1 == stat(dev_name, &st)) { //��dev_name��״̬���Ƶ�st����
		fprintf(stderr, "Cannot identify '%s': %d, %s\n", dev_name, errno, strerror(errno));
		exit(EXIT_FAILURE);
	}
	if (!S_ISCHR(st.st_mode)) { //�ж��Ƿ��ַ�
		fprintf(stderr, "%s is no device\n", dev_name);
		exit(EXIT_FAILURE);
	}
	fd = open(dev_name, O_RDWR /* required */ | O_NONBLOCK, 0);//���豸 �ɹ������·�����ļ�������  �ɶ���д�� �����豸�ļ�����O_NONBLOCK��ʽ�򿪿�����������I/O��Nonblock I/O����
	if (-1 == fd) {
		fprintf(stderr, "Cannot open '%s': %d, %s\n",
			dev_name, errno, strerror(errno));
		exit(EXIT_FAILURE);
	}
}

static void usage(FILE * fp, int argc, char ** argv)
{
	fprintf(fp,
		"Usage: %s [options]\n\n"
		"Options:\n"
		"-d | --device name Video device name [/dev/video]\n"
		"-h | --help Print this message\n"
		"-m | --mmap Use memory mapped buffers\n"
		"-r | --read Use read() calls\n"
		"-u | --userp Use application allocated buffers\n"
		"",
		argv[0]);
}

static const char short_options[] = "d:hmru";
static const struct option long_options[] = {
	{ "device", required_argument, NULL, 'd' },
	{ "help", no_argument, NULL, 'h' },
	{ "mmap", no_argument, NULL, 'm' },
	{ "read", no_argument, NULL, 'r' },
	{ "userp", no_argument, NULL, 'u' },
	{ 0, 0, 0, 0 }
};
int main(int argc, char ** argv)
{
	dev_name = "/dev/video0";
	for (;;) {
		int index;
		int c;
		c = getopt_long(argc, argv, short_options, long_options, &index);
		if (-1 == c)
			break;
		switch (c) {
		case 0: /* getopt_long() flag */
			break;
		case 'd':
			dev_name = optarg;
			break;
		case 'h':
			usage(stdout, argc, argv);
			exit(EXIT_SUCCESS);
		case 'm':
			io = IO_METHOD_MMAP;
			break;
		case 'r':
			io = IO_METHOD_READ;
			break;
		case 'u':
			io = IO_METHOD_USERPTR;
			break;
		default:
			usage(stderr, argc, argv);
			exit(EXIT_FAILURE);
		}
	}
	open_device();
	init_device();
	start_capturing();
	mainloop();
	stop_capturing();
	uninit_device();
	close_device();
	exit(EXIT_SUCCESS);
	return 0;
} 
