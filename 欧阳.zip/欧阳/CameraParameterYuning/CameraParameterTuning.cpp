#include<opencv2/opencv.hpp>
#include<iostream>
#include<iomanip>
using namespace cv;   
using namespace std;
int main()
{
    VideoCapture capture("/dev/video0");
     double a=capture.set(CV_CAP_PROP_EXPOSURE, 50);//曝光 50
    double b=capture.get(CV_CAP_PROP_FRAME_WIDTH);//width
    double c=capture.get(CV_CAP_PROP_FRAME_HEIGHT);//height
    double d=capture.get(CV_CAP_PROP_FPS);//fps
    double e=capture.get(CV_CAP_PROP_BRIGHTNESS);//liang du
    double f=capture.get(CV_CAP_PROP_CONTRAST);//dui bi du
    double g=capture.get(CV_CAP_PROP_SATURATION);//bao he du
    double h=capture.get(CV_CAP_PROP_HUE);//se diao
    double i=capture.get(CV_CAP_PROP_EXPOSURE);//bao guan
    double j=capture.get(CV_CAP_PROP_FRAME_COUNT);//视频帧数
    cout <<"baoguang"<<a<<"  "<<"fps"<<d<<endl;
    cout <<"liangdu"<< e <<"  "<<"duibidu"<<f<<endl;
    cout<<"baohedu"<<g<<"  "<<"sediao"<<h<<endl;
    cout<<"baoguang"<<i<<"  "<<"视频帧数"<<j;
    capture.set(CV_CAP_PROP_FRAME_WIDTH, 960);//宽度 
    capture.set(CV_CAP_PROP_FRAME_HEIGHT, 720);//高度
    capture.set(CV_CAP_PROP_FPS, 30);//帧率 帧/秒
    capture.set(CV_CAP_PROP_BRIGHTNESS, 0.00);//亮度 1
    capture.set(CV_CAP_PROP_CONTRAST,0.20);//对比度 40
    capture.set(CV_CAP_PROP_SATURATION, 0.12);//饱和度 50
    capture.set(CV_CAP_PROP_HUE, -1);//色调 50
    a=capture.set(CV_CAP_PROP_EXPOSURE, 50);//曝光 50
    //b=capture.get(CV_CAP_PROP_FRAME_WIDTH);//width
    //c=capture.get(CV_CAP_PROP_FRAME_HEIGHT);//height
    d=capture.get(CV_CAP_PROP_FPS);//fps
    e=capture.get(CV_CAP_PROP_BRIGHTNESS);//liang du
    f=capture.get(CV_CAP_PROP_CONTRAST);//dui bi du
    g=capture.get(CV_CAP_PROP_SATURATION);//bao he du
    h=capture.get(CV_CAP_PROP_HUE);//se diao
    i=capture.get(CV_CAP_PROP_EXPOSURE);//bao guan
    j=capture.get(CV_CAP_PROP_FRAME_COUNT);//视频帧数
    cout <<"change"<<endl;
    cout <<"baoguang"<<a<<"  "<<"fps"<<d<<endl;
    cout <<"liangdu"<< e <<"  "<<"duibidu"<<f<<endl;
    cout<<"baohedu"<<g<<"  "<<"sediao"<<h<<endl;
    cout<<"baoguang"<<i<<"  "<<"视频帧数"<<j;
    while (1)
        {
            Mat frame;
            capture >> frame;
            namedWindow("video");
            imshow("video",frame);
                 int z = cvWaitKey(30);
                if (z== 27)//Esc键退出
                {
                        break;
                }
        }
        return 0;
}
 
