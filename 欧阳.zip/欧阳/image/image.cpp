#include<errno.h>
#include<string.h>
#include<fcntl.h>
#include<termios.h>
#include<unistd.h>
#include <opencv2/core.hpp> 
#include <iostream>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/ml/ml.hpp>
#include <vector>
#include <opencv2/core/core.hpp>
#include <string>
#include <math.h>
#include <algorithm>
#include <iosfwd>
#include <memory>
#include <utility>
#include <fstream>
#include <string.h>
#include <thread>
#include <mutex>
#include <vector>
#include <stdint.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>
#include <stdio.h>
#include <iostream>
#include <vector>
#define TXPackSize 20
#ifndef BYTE
#define BYTE unsigned char
#endif
// #ifdef _RM_DEC_TK1
// #define RXPackSize 21
// #else
// #define RXPackSize 20
// #endif
#define RXPackSize 10
#define RX_BUFFER_SIZE RXPackSize + 2

//数据准备。。
uint16_t Get_CRC16_Check_Sum(uint8_t *pchMessage,uint32_t dwLength,uint16_t wCRC);
uint32_t Verify_CRC16_Check_Sum(uint8_t *pchMessage, uint32_t dwLength);
void Append_CRC16_Check_Sum(uint8_t * pchMessage,uint32_t dwLength);
unsigned char Get_CRC8_Check_Sum(unsigned char *pchMessage,unsigned int dwLength,unsigned char ucCRC8);
unsigned int Verify_CRC8_Check_Sum(unsigned char *pchMessage, unsigned int dwLength);
void Append_CRC8_Check_Sum(unsigned char *pchMessage, unsigned int dwLength);
using namespace std;
typedef struct {
	int armor_thres_red;
	int armor_thres_blue;
	int debug_flag;
	int debug_mode;
	int x;
	int y;
	int z;
	int armor_exp_red;
	int armor_exp_blue;
	int sudoku_exp;
	int sudokunew_exp;
	int sudoku_led_thres;
	int sudokunew_led_thres;
	int sudokunew_board_thres;
	int bulletadd_exp;
	int bullet_thres;
	int writemov;
	int usevideo;
	string video_path;
	float mono_small_armor_720p_const;
	float mono_small_armor_1080p_const;
	float mono_big_armor_720p_const;
	float mono_big_armor_1080p_const;
	float mono_f_720p;
	float mono_f_1080p;
	float mono_base_720p;
	float mono_base_1080p;
	float mono_x;
	float mono_y;
	float mono_z;
}InitParams;
typedef struct {
	typedef enum {
		small_armor,
		big_armor
	}armor_type;
	cv::Point center;
	float area;
	float distance;//mm
	armor_type armor;
}Monodata;
using namespace cv;
template<typename T>
Mat frame;
Mat edge;
Mat contourThreadkernel = getStructuringElement(MORPH_ELLIPSE, Size(9, 9));
void ContourThread(int mode, Mat input, Mat &binary, int thres, vector<vector<Point> > &contours) {
	Mat thres_whole;
	vector<Mat> splited;
	split(input, splited);
	cvtColor(input, thres_whole, CV_BGR2GRAY);

	threshold(thres_whole, thres_whole, 100, 255, THRESH_BINARY);
	if (mode == 0) {
		subtract(splited[2], splited[0], binary);
		threshold(binary, binary, thres, 255, THRESH_BINARY);// red
	}
	else {
		subtract(splited[0], splited[2], binary);
		threshold(binary, binary, thres, 255, THRESH_BINARY);// blue
	}
	dilate(binary, binary, contourThreadkernel);
	binary = binary & thres_whole;
	findContours(binary, contours, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE);
}

static inline bool PairSort(std::pair<Point, Rect> a1, std::pair<Point, Rect> a2) {
	return a1.first.x < a2.first.x;
}

static inline bool RotateRectSort(RotatedRect a1, RotatedRect a2) {
	return a1.center.x < a2.center.x;
}

class ArmorFind
{
public:
	ArmorFind();
	void process(vector<vector<Point> > contours, const Mat &input, Mat &output, vector<Point> &result, bool ismono);
	void ContourCenter(const vector<Point> contour, Point &center);
	void RotateRectLine(RotatedRect rect, Point &lineup, Point &linedown);
	double Pointdis(const Point &p1, const Point &p2);
	Point PointBetween(const Point &p1, const Point &p2);
	void Clear(void);
	void GetArmorLights(void);
public:
	void GetArmors(Mat &image, bool ismono);
	double GetK(Point2f L1, Point2f L2);
	void DrawCross(Mat &img, Point center, int size, Scalar color, int thickness = 2);

public:
	Point2f _pt[4], pt[4];
	Mat binary;
	vector<Point> ArmorCenters, ArmorOldCenters;
	vector<Monodata> monodata;
	int ArmorLostDelay;
	int armormin;
	Mat kernel;
	vector<vector<RotatedRect> > Armorlists;
	vector<int> CellMaxs;
	vector<Mat> splited;
	vector<vector<Point> > final;
	vector<Rect> Target;
	vector<Point> centers;
	vector<std::pair<Point, Rect> > PairContour;
	vector<RotatedRect> RectfirstResult, RectResults;
	Mat armor_roi;
    double pitch1,yaw1;
};
 
ArmorFind::ArmorFind()
{
	ArmorLostDelay = 0;
	armormin = 10;
	kernel = getStructuringElement(MORPH_ELLIPSE, Size(9, 9));
}

void ArmorFind::process(vector<vector<Point> > contours, const Mat &input, Mat &output, vector<Point> &result, bool ismono) {
	Clear();
	output = input.clone();
	RotatedRect RRect;
	for (int i = 0; i < contours.size(); i++) {
		RRect = minAreaRect(contours[i]);
		if ((fabs(RRect.angle) < 45.0 && RRect.size.height > RRect.size.width)
			|| (fabs(RRect.angle) > 45.0 && RRect.size.width > RRect.size.height)
			) {
			RectfirstResult.push_back(RRect);
		}
	}
	if (RectfirstResult.size() < 2) {
		ArmorCenters.clear();
		return;

	}
	sort(RectfirstResult.begin(), RectfirstResult.end(), RotateRectSort);
	GetArmorLights();
	sort(RectResults.begin(), RectResults.end(), RotateRectSort);
	for (int i = 0; i < RectResults.size(); i++) {
		//std::cout << "(" <<atan((RectResults[i].center.x-320)/1344.1) <<"\n" << atan(((RectResults[i].center.y-240)/1344.52))<< ")" << std::endl;
		//ellipse(output, RectResults[i], Scalar(255, 0, 0), 2);
	}
	GetArmors(output, ismono);
        for ( int i = 0; i < ArmorCenters.size(); i++) {
		DrawCross(output, ArmorCenters[i], 20, Scalar(255, 0, 255), 2);
	}
	result = ArmorCenters;
}
void ArmorFind::DrawCross(Mat &img, Point center, int size, Scalar color, int thickness) {
	Point L1, L2, B1, B2;
	int xL = center.x - size > 0 ? center.x - size : 0;
	int xR = center.x + size;
	int yL = center.y - size > 0 ? center.y - size : 0;
	int yR = center.y + size;
	L1 = Point(xL, center.y);
	L2 = Point(xR, center.y);
	B1 = Point(center.x, yL);
	B2 = Point(center.x, yR);
	pitch1=atan(((L1.x + L2.x+ B1.x +B2.x)/4-320)/1344.1)*100;
	yaw1=atan(((L1.y + L2.y + B1.y + B2.y) / 4 - 240) / 1345.2) * 100;
	line(img, L1, L2, color, thickness);
	line(img, B1, B2, color, thickness);

}
void ArmorFind::GetArmorLights() {
	size_t size = RectfirstResult.size();
	vector<RotatedRect> Groups;
	int cellmaxsize;
	Groups.push_back(RectfirstResult[0]);
	cellmaxsize = RectfirstResult[0].size.height * RectfirstResult[0].size.width;
	if (cellmaxsize > 2500) cellmaxsize = 0;
	int maxsize;

	for (int i = 1; i < size; i++) {
		if (RectfirstResult[i].center.x - RectfirstResult[i - 1].center.x < 10) {
			maxsize = RectfirstResult[i].size.height * RectfirstResult[i].size.width;
			if (maxsize > 2500) continue;
			if (maxsize > cellmaxsize) cellmaxsize = maxsize;
			Groups.push_back(RectfirstResult[i]);
		}
		else {
			Armorlists.push_back(Groups); \
				CellMaxs.push_back(cellmaxsize);
			cellmaxsize = 0;
			maxsize = 0;
			Groups.clear();
			Groups.push_back(RectfirstResult[i]);
			cellmaxsize = RectfirstResult[i].size.height * RectfirstResult[i].size.width;
		}
	}
	Armorlists.push_back(Groups); \
		CellMaxs.push_back(cellmaxsize);
	size = Armorlists.size();
	for (int i = 0; i < size; i++) {
		int Gsize = Armorlists[i].size();
		int GroupMax = CellMaxs[i];
		if (GroupMax > 5) {
			for (int j = 0; j < Gsize; j++) {
				maxsize = Armorlists[i][j].size.height * Armorlists[i][j].size.width;
				if (maxsize == GroupMax) {
					RectResults.push_back(Armorlists[i][j]);
				}
			}
		}
	}
}
void ArmorFind::GetArmors(Mat &image, bool ismono) {
	size_t size = RectResults.size();
	ArmorOldCenters = ArmorCenters;
	ArmorCenters.clear();
	if (size < 2) {
		return;
	}
	Point2f L1, L2;
	float K, angleabs = 0.0, angleL1, angleL2;
	float divscale, areaL1, areaL2;
	float ydis = 0;
	float maxangle, xdis, heightmax, hwdiv;
	//Point2f _pt[4], pt[4];
	auto ptangle = [](const Point2f &p1, const Point2f &p2) {
		return fabs(atan2(p2.y - p1.y, p2.x - p1.x)*180.0 / CV_PI);
	};
	auto GetAreaofp3 = [](const Point2f &p1, const Point2f &p2, const Point2f &p3) {
		Mat matrix = (Mat_<double>(3, 3) << p1.x, p2.y, 1, p2.x, p2.y, 1, p3.x, p3.y, 1);
		return 0.5*determinant(matrix);
	};

	for (int i = 0; i < size - 1; i++) {
		angleL1 = fabs(RectResults[i].angle);
		L1 = RectResults[i].center;
		areaL1 = RectResults[i].size.height * RectResults[i].size.width;
		RectResults[i].points(_pt);
		if (angleL1 > 45.0) {
			pt[0] = _pt[3];
			pt[1] = _pt[0];
		}
		else {
			pt[0] = _pt[2];
			pt[1] = _pt[3];
		}
		for (int j = i + 1; j < size; j++) {
			L2 = RectResults[j].center;
			if (L1.x != L2.x) {
				K = GetK(L1, L2);
				if (L1.y > L2.y) {
					ydis = L1.y - L2.y;
				}
				else {
					ydis = L2.y - L1.y;
				}
				areaL2 = RectResults[j].size.height * RectResults[j].size.width;
				if (areaL1 > areaL2) {
					divscale = areaL1 / areaL2;
				}
				else {
					divscale = areaL2 / areaL1;
				}
				angleL2 = fabs(RectResults[j].angle);

				RectResults[j].points(_pt);
				if (angleL2 > 45.0) {
					pt[2] = _pt[2];
					pt[3] = _pt[1];
				}
				else {
					pt[2] = _pt[1];
					pt[3] = _pt[0];
				}
				maxangle = MAX(ptangle(pt[0], pt[2]), ptangle(pt[1], pt[3]));
				if (angleL1 > 45.0 && angleL2 < 45.0) {
					angleabs = 90.0 - angleL1 + angleL2;
				}
				else if (angleL1 <= 45.0 && angleL2 >= 45.0) {
					angleabs = 90.0 - angleL2 + angleL1;
				}
				else {
					if (angleL1 > angleL2) angleabs = angleL1 - angleL2;
					else angleabs = angleL2 - angleL1;
				}
				xdis = fabs(L1.x - L2.x);
				heightmax = MAX(MAX(RectResults[i].size.width, RectResults[j].size.width), MAX(RectResults[i].size.height, RectResults[j].size.height));
				hwdiv = xdis / heightmax;
				if (fabs(K) < 0.5 && divscale < 3.0 && maxangle < 20.0 && hwdiv < 10.0 && ydis < 0.4*heightmax) {//&& ydis < armormin
					if (angleabs < 7) {
						if (ismono) {
							float armor_area = GetAreaofp3(pt[0], pt[1], pt[2]) + GetAreaofp3(pt[1], pt[2], pt[3]);
							Monodata pushdata;
							pushdata.area = armor_area;
							pushdata.center = Point(0.5*(L1.x + L2.x), 0.5*(L1.y + L2.y));
							if (hwdiv > 5.0) {
								pushdata.armor = pushdata.big_armor;
							}
							else {
								pushdata.armor = pushdata.small_armor;
							}
							monodata.push_back(pushdata);
							ArmorCenters.push_back(Point(0.5*(L1.x + L2.x), 0.5*(L1.y + L2.y)));
							ArmorLostDelay = 0;
						}
						else {
							ArmorCenters.push_back(Point(0.5*(L1.x + L2.x), 0.5*(L1.y + L2.y)));
							ArmorLostDelay = 0;
						}
					}
				}
				//cout << pt[0] <<"  "<< pt[1]<<"  "<< pt[2]<<"  "<< pt[3]<<"\n";
			}
		}
	}
	if (ArmorCenters.size() == 0) {
		ArmorLostDelay++;
		if (ArmorLostDelay < 10) {
			ArmorCenters = ArmorOldCenters;
		}
	}
}
double ArmorFind::GetK(Point2f L1, Point2f L2) {
	return (L1.y - L2.y) / (L1.x - L2.x);
}

void ArmorFind::RotateRectLine(RotatedRect rect, Point &lineup, Point &linedown) {
	Point2f pt[4];
	rect.points(pt);
	Point rep[2];
	if (Pointdis(pt[0], pt[1]) < Pointdis(pt[1], pt[2])) {
		rep[0] = PointBetween(pt[0], pt[1]);
		rep[1] = PointBetween(pt[2], pt[3]);
	}
	else {
		rep[0] = PointBetween(pt[1], pt[2]);
		rep[1] = PointBetween(pt[0], pt[3]);
	}
	if (rep[0].y > rep[1].y) {
		lineup = rep[1];
		linedown = rep[0];
	}
	else {
		lineup = rep[0];
		linedown = rep[1];
	}
}
double ArmorFind::Pointdis(const Point &p1, const Point &p2) {
	return sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
}

Point ArmorFind::PointBetween(const Point &p1, const Point &p2) {
	return Point((p1.x + p2.x) / 2, (p1.y + p2.y) / 2);
}

void ArmorFind::ContourCenter(const vector<Point> contour, Point &center) {
	Moments mu;
	mu = moments(contour, false);
	center.x = mu.m10 / mu.m00;
	center.y = mu.m01 / mu.m00;
}
void ArmorFind::Clear(void) {
	monodata.clear();
	CellMaxs.clear();
	Armorlists.clear();
	RectfirstResult.clear();
	RectResults.clear();
	Target.clear();
	final.clear();
	PairContour.clear();
	centers.clear();
}
class SerialCom
{
public:
    //short m_frame_flag_pc;
    double yaw;//x
    double pitch;//y
    double speed;
    int k;
    //short m_frame_flag;  //帧标志位
    double send_time=0;
    BYTE sendata[TXPackSize];
    int fd;
    SerialCom();
    ~SerialCom();
    int init();
    bool open_port();
    void double2byte(BYTE *hexdata, double ddata);

    //
    //inline int getBuffMode(){return m_buff_mode;}
    //inline short getFrameFlag(){return m_frame_flag;}
   // inline void setFrameFlag(short flag){m_frame_flag = flag;}
    int send(unsigned char *str,int );
    void getdata();
    //int decodeData();
    int set_interface_attribs(int fd, int speed, int parity);
    void set_blocking(int fd, int should_block);
    template <typename T>
    static inline char combData(T data_l, T data_h)
    {
        return (data_l & 0x0f) | ((data_h << 4) & 0xf0);
    }

};


SerialCom::SerialCom()
{
    m_frame_flag_pc = 0;
    m_buff_mode = 0;
    m_stable = 0;
    m_frame_flag = 0;
}

SerialCom::~SerialCom()
{
    close(fd);
    std::cout << "-- SerialCom Destructor successfully!" << std::endl;
}
int SerialCom::set_interface_attribs(int fd, int speed, int parity)//波特率校验,奇偶校验，及各项参数设计
{
    struct termios tty;
    memset(&tty, 0, sizeof tty);
    if (tcgetattr(fd, &tty) != 0)
    {
        // error_message ("error %d from tcgetattr", errno);
        return -1;
    }

    cfsetospeed(&tty, speed);
    cfsetispeed(&tty, speed);

    tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8; // 8-bit chars
    // disable IGNBRK for mismatched speed tests; otherwise receive break
    // as \000 chars
    tty.c_iflag &= ~IGNBRK; // disable break processing
    tty.c_lflag = 0;        // no signaling chars, no echo,
    // no canonical processing
    tty.c_oflag = 0;     // no remapping, no delays
    tty.c_cc[VMIN] = 0;  // read doesn't block
    tty.c_cc[VTIME] = 1; // 0.5 seconds read timeout

    tty.c_iflag &= ~(IXON | IXOFF | IXANY); // shut off xon/xoff ctrl

    tty.c_cflag |= (CLOCAL | CREAD); // ignore modem controls,
    // enable reading
    tty.c_cflag &= ~(PARENB | PARODD); // shut off parity
    tty.c_cflag |= parity;
    // tty.c_cflag &= ~CSTOPB;
    tty.c_cflag |= CSTOPB;

    tty.c_cflag &= ~CRTSCTS;

    if (tcsetattr(fd, TCSANOW, &tty) != 0)
    {
        // error_message ("error %d from tcsetattr", errno);
        return -1;
    }
    return 0;
}

void SerialCom::set_blocking(int fd, int should_block)
{
    struct termios tty;
    memset(&tty, 0, sizeof tty);
    if (tcgetattr(fd, &tty) != 0)
    {
        //        error_message ("error %d from tggetattr", errno);
        return;
    }

    tty.c_cc[VMIN] = should_block ? 1 : 0;
    tty.c_cc[VTIME] = 1; // 0.5 seconds read timeout

    if (tcsetattr(fd, TCSANOW, &tty) != 0)
        ;
    //("error %d setting term attributes", errno);
}
int SerialCom::init()
{
    // int fd = open("/dev/ttyS0", O_RDWR | O_NOCTTY);
    int found_flag = false;
    int fd;
    std::string serial_path = "/dev/ttyUSB0" ;//打开串口
    fd = open(serial_path.c_str(), O_RDWR | O_NOCTTY);
    std::cout << "fd is: " << fd << std::endl;
    set_interface_attribs(fd, B115200, 0); // set speed to 115,200 bps,ot 8n1 (no parity)
    set_blocking(fd, 0); // set no blocking
    return fd;
}
bool SerialCom::open_port()
{
    fd = init();
    if (fd > 0)
    {
        std::cout<<"T";
        return true;
    }
    else
    {   std::cout<<"F";
        return false;
    }
}

int SerialCom::send(unsigned char *str, int len)
{
    int n = write(this->fd, str, len);
    return n;
}
void SerialCom::getdata(){
    //open_port();
    sendata[0] = '!';//数据头1
    sendata[7] = '.';

//将double x,y,z依次转成byte类型
            double2byte(&sendata[1], int(yaw+0.5));
            double2byte(&sendata[4], int(pitch+0.5));
         


//发送到串口并检查是否发送成功
    int nr;
    nr = send(sendata,8);
    std:: cout<<sendata;
    if (nr > 0) printf("send data to uart success! nr=%d\n", nr);
    else ;//printf("\n send data to uart fail!");
}
void SerialCom::double2byte(BYTE *hexdata, double ddata)
{
    unsigned char str[128];
    sprintf((char*)str, "%f", ddata);
    hexdata[0] = str[0];
    hexdata[1] = str[1];
    hexdata[2] = str[2];
    hexdata[3] = str[3];
}
int main() {
	Mat frame;
	VideoCapture capture("/dev/video0");
        capture.set(CV_CAP_PROP_FRAME_WIDTH, 640);//宽度 
        capture.set(CV_CAP_PROP_FRAME_HEIGHT, 480);//高度
        //int q=capture.get(CV_CAP_PROP_EXPOSURE);
        //cout << q<<endl;
        //capture.set(CV_CAP_PROP_EXPOSURE,-10);
        int w=capture.get(CV_CAP_PROP_EXPOSURE);
        //cout << w <<endl ;
	Mat output;
	vector<vector<Point> > contours;
	vector<Point> result;
	ArmorFind a;
	SerialCom b;
        b.open_port();
	while (true)
	{
		int i,flag;
		a.pitch1=0.00;
		a.yaw1=0.00;
		flag=10;
		capture >> frame;
		//imshow("Video", frame);
		//cout << a.pt[0] << a.pt[1] << a.pt[2] << a.pt[3];
		ContourThread(0, frame, output, THRESH_BINARY, contours);
		a.process(contours, frame, output, result, true);
		if(a.pitch1!=0.00||a.yaw1!=0.00)
		{  
                b.yaw=int(a.yaw1+190+0.3);
                b.pitch=int(a.pitch1+190+0.3);
               
                b.getdata();
                flag=15;
		}
                if(flag==10)
                {
                b.yaw=190;
                b.pitch=190;
                b.k=0;
           
                b.getdata();}
                
		double time0 = static_cast<double>(getTickCount()); 	
		capture >> frame;  	 	
		if (frame.empty())
		{
			break;
		}
		cout << "帧率" << getTickFrequency() / (getTickCount() - time0) << endl;
		 
		if (frame.empty())
			break;
                imshow("Video1", output);
		if (waitKey(50) == 27)
		{
			break;
		}
	}
	return 0;
}
 
